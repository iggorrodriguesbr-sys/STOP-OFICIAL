# Stop Jaguary - Divisão dos 10%

Aplicativo para celular que divide os 10% dos garçons do Stop Jaguary (Pastelaria & Lanchonete, Jaguariúna, SP).

- Todo dia: marca quem trabalhou e soma as comandas; o app divide os 10% entre quem trabalhou naquele dia
- Na segunda: a aba Semana soma tudo e mostra quanto pagar para cada garçom (só pelos dias em que ele trabalhou), com botão Pagar
- Garçons cadastrados ficam salvos
- Exporta relatório, planilha e resumo para WhatsApp da semana
- Cópia de segurança: salvar e restaurar os dados (também serve para trocar de celular)
- Funciona sem internet depois da primeira abertura
- Tudo fica salvo no próprio celular (nenhum dado vai para a internet)

## Como publicar no GitHub (pelo celular ou computador)

1. Crie uma conta em github.com e entre nela.
2. Toque em **+** > **New repository**. Nome: `stop-jaguary`. Marque **Public** e toque em **Create repository**.
3. Toque em **uploading an existing file** e envie todos os arquivos desta pasta (`index.html`, `manifest.webmanifest`, `sw.js`, `icon.svg`, `icon-192.png`, `icon-512.png`, `apple-touch-icon.png`). O `README.md` é opcional. Toque em **Commit changes**.
4. Vá em **Settings** > **Pages**. Em **Source**, escolha **Deploy from a branch**. Em **Branch**, escolha `main` e a pasta `/ (root)`, e toque em **Save**.
5. Espere 1 a 2 minutos. O endereço do app será:
   `https://SEU-USUARIO.github.io/stop-jaguary/`

## Como instalar no celular

- **iPhone (Safari):** abra o endereço, toque em Compartilhar e depois em **Adicionar à Tela de Início**.
- **Android (Chrome):** abra o endereço, toque nos três pontinhos e depois em **Instalar aplicativo** (ou **Adicionar à tela inicial**).

## Cuidados

- Os dados ficam só no celular em que o app é usado. Outro celular não vê o histórico.
- Limpar os dados do navegador apaga o histórico. Use **Exportar histórico** de vez em quando como backup.
- Para atualizar o app, envie o novo `index.html` no mesmo repositório. Na próxima abertura com internet, ele atualiza sozinho.

## Se aparecer erro 404

O erro 404 quase sempre quer dizer que o GitHub não achou o arquivo `index.html` na pasta principal do repositório. Confira:

1. Abra o repositório. Na lista de arquivos da tela inicial (sem entrar em nenhuma pasta) precisa aparecer `index.html`. Se ele estiver dentro de uma pasta, envie de novo, solto.
2. O nome precisa ser exatamente `index.html`, tudo minúsculo, sem espaço e sem `(1)`. Nomes como `index`, `index.html.txt` ou `index (1).html` não funcionam.
3. O zip não abre sozinho no GitHub. Envie os arquivos de dentro dele, soltos.
4. Em Settings > Pages, confira se está em Deploy from a branch, branch `main`, pasta `/ (root)`.
5. O endereço usa o nome do repositório: `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`. Letras maiúsculas e minúsculas contam.
